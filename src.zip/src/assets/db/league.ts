export const League = [
  ['    ##      ', 'AliRn ', 'AliReza', 'Reza ', 'MohammadReza', 'Behnam', 'AliReza-D '],
  ['AliRn       ', '  ##  ', '      ', ' 3-0  ', '            ', '      ', '          '],
  ['AliReza     ', '      ', '  ##  ', '      ', '    0-2     ', '      ', '          '],
  ['Reza        ', '      ', '      ', '  ##  ', '    1-2     ', '      ', '          '],
  ['MohammadReza', '      ', '      ', '      ', '     ##     ', '      ', '          '],
  ['Behnam      ', '      ', '      ', '      ', '            ', '  ##  ', '          '],
  ['AliReza-D   ', '      ', '      ', '      ', '            ', '      ', '     ##   '],
]
