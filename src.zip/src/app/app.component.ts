import {Component, OnInit} from '@angular/core';
import {Rankings} from "../assets/db/ranking";
import {League} from "../assets/db/league";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  constructor() {
  }

  ngOnInit() {
  }

  league = League;
  ranks = Rankings;
}
