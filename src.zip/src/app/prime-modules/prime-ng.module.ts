import {NgModule} from '@angular/core';
import {MODULES} from '.';

@NgModule({
  exports: [MODULES],
})
export class PrimeNgModule {}
