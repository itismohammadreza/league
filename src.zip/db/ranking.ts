const ali = new Ranking({
  name: 'AliRn',
  match_played: 10,
  win: 2,
  draw: 0,
  lose: 1,
  gf: 10,
  ga: 7,
  gd: 3,
  point: 10
})

const mohammadReza = new Ranking({
  name: 'MohammadReza',
  match_played: 10,
  win: 2,
  draw: 0,
  lose: 1,
  gf: 10,
  ga: 7,
  gd: 3,
  point: 10
})

const behnam = new Ranking({
  name: 'Behnam',
  match_played: 10,
  win: 2,
  draw: 0,
  lose: 1,
  gf: 10,
  ga: 7,
  gd: 3,
  point: 10
})

const aliRezaD = new Ranking({
  name: 'AliReza-D',
  match_played: 10,
  win: 2,
  draw: 0,
  lose: 1,
  gf: 10,
  ga: 7,
  gd: 3,
  point: 10
})

const aliReza = new Ranking({
  name: 'AliReza',
  match_played: 10,
  win: 2,
  draw: 0,
  lose: 1,
  gf: 10,
  ga: 7,
  gd: 3,
  point: 10
})

const reza = new Ranking({
  name: 'Reza',
  match_played: 10,
  win: 2,
  draw: 0,
  lose: 1,
  gf: 10,
  ga: 7,
  gd: 3,
  point: 10
})

let ranking = [ali, mohammadReza, behnam, aliRezaD, aliReza, reza]
